/* eslint-disable prettier/prettier */
// withBackgroundColor.js
import React from 'react';
import { View } from 'react-native';
const WithBackgroundColor = (WrappedComponent, color) => {
  return (props) => {
    return (
      <View style={{ backgroundColor: color }}>
        <WrappedComponent {...props} />
      </View>
    );
  };
};
export default WithBackgroundColor;
