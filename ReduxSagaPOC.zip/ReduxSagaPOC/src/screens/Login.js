/* eslint-disable react-native/no-inline-styles */
/* eslint-disable prettier/prettier */
import React, { useEffect } from 'react';
import {
  View,
  Image,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Text,
} from 'react-native';
import axios from 'axios';
import { useState } from 'react';
import Counter from './Counter';
// Imports: Dependencies
import { Provider } from 'react-redux';
// Imports: Redux Store
import { store } from 'src/store/store';
import WithBackgroundColor from 'src/hoc/WithBackgroundColor';

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [username, setUserName] = useState("kminchelle");
  const [password, setPassword] = useState("0lelplR");
  const [data, setData] = useState(null);
  const [disabledLogin, setLoginDisabled] = useState(true);

  const EnhancedContainer = WithBackgroundColor(View, '#FDB8CC');


  useEffect(() => {
    if (username !== "" && password !== ""){
      setLoginDisabled(false);
    } else {
      setLoginDisabled(true);
    }
  }, [username, password]);
  // This is for demo only, normally you want to create an api wrapper
  const callLoginAPI = async () => {
    try {
      await axios.post(
        'https://dummyjson.com/auth/login',
        {
          username: username,
          password: password,
           //other data key value pairs
        },
        {
           headers: {
               'api-token': 'xyz',
                //other header fields
           }
        }
    );
      setLoading(false);
      fetchData();
    } catch (e) {
      setLoading(false);
      setError(e.message);
    }
  };

  //Dummy function to fetch data
  const fetchData = async () => {
    try {
      const response = await axios.get(
        'https://dummyjson.com/products',
      );
      setData(response.data?.products[0]);
      setLoading(false);
    } catch (e) {
      setError(e);
      setLoading(false);
    }
  };

    return (
      <View style={styles.container}>
       <EnhancedContainer style={styles.container}>
       
        { !loading && !data && <View
          style={styles.div1}
        >
          <Image
           style={[
            {
              width: '50%',
              height: '50%',
              overflow: 'visible',
              marginLeft : 90
            }
            ]}
             source={require('../images/test.jpeg')}
          />
        <TextInput
          placeholder="Username"
          value = {username}
          style={[styles.textInput, { marginTop: 40 }]}
          onChangeText={text => setUserName(text)}
        />
        <TextInput
          placeholder="Password"
          value = {password}
          style={[styles.textInput, { marginVertical: 20 }]}
          onChangeText={text => setPassword(text)}
        />

        <TouchableOpacity
        disabled = {disabledLogin}
          onPress={() => {
            callLoginAPI();
          }}
          style={disabledLogin ? styles.disabledButton: styles.button}
        >
          <Text style={{ color: 'white', fontSize: 20, fontWeight: '600' }}>
            LOGIN
          </Text>
        </TouchableOpacity>
        {error && <Text style={styles.errorText}>Error Occurred : {error}</Text>}
        </View>}
        { data && <View>
          <TouchableOpacity
              onPress={() => {
                setData(null);
              }}
            style={styles.logoutButton}
            >
            <Text style={{ color: 'white', fontSize: 20, fontWeight: '600' }}>
              LOGOUT
            </Text>
          </TouchableOpacity>
          <View
        style={{
          padding: 50,
          marginVertical: 8,
          marginHorizontal: 16,
          marginTop : 150,
          backgroundColor: '#F88379',
        }}>
            <Text style={{fontSize: 15, color : "white", fontFamily : "Comic Sans MS", margin : 5}}> Title : {data.title}</Text>
            <Text style={{fontSize: 15, color : "white" ,fontFamily : "Comic Sans MS", margin : 5}}> Brand : {data.brand}</Text>
            <Text style={{fontSize: 15, color : "white", fontFamily : "Comic Sans MS", margin : 5}}> Description : {data.description}</Text>
            <Text style={{fontSize: 15, color : "white", fontFamily : "Comic Sans MS", margin : 5}}> Price : {data.price}</Text>
            <Text style={{fontSize: 15, color : "white", fontFamily : "Comic Sans MS", margin : 5}}> Rating : {data.rating}</Text>
            </View>

          </View>
          }
          { !loading && data && <Provider store={store}>
            <Counter />
          </Provider>}
        </EnhancedContainer>
          
      </View>
    
    );
  }

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 26,
    paddingTop: 26,
    paddingBottom: 18,
  },
  logo: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'grey'
  },
  textInput: {
    height: 60,
    borderRadius: 3,
    borderWidth: 1,
    borderColor: '#ECF0F3',
    paddingHorizontal: 19,
    width : 350
  },
  button: {
    height: 60,
    borderRadius: 5,
    backgroundColor: '#F88379',
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledButton : {
    height: 60,
    borderRadius: 5,
    backgroundColor: 'grey',
    justifyContent: 'center',
    alignItems: 'center'
  },
  logoutButton : {
    height: 20,
    width : 100
  },
  div1 :{
    marginLeft : 100,
    marginRight : 100
  },
  errorText : {
    marginTop : 10,
    color : "red",
    fontWeight : 300
  }
});

export default Login;
